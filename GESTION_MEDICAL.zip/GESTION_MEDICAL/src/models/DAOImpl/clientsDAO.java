package models.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DAO;
import models.clients;

public class clientsDAO extends DAO<clients> {

	public clients create(clients cl) {
		try {
			 
		
			ResultSet result = this	.connect
                                    .createStatement(
                                    		ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                    		ResultSet.CONCUR_UPDATABLE
                                    ).executeQuery(
                                    		"SELECT NEXTVAL('client_id_seq') as ID"
                                    );
			if(result.first()){
				int ID = result.getInt("ID");
    			PreparedStatement prepare = this	.connect
                                                    .prepareStatement(
                                                    	"INSERT INTO clients (ID, VERSION,TITRE,NOM,PRENOM VALUES(?,?,?,?,?)"
                                                    );
				prepare.setInt(1, ID);
				prepare.setInt(2, cl.getVERSION());
				prepare.setString(3, cl.getTITRE());
				prepare.setString(4, cl.getNOM());
				prepare.setString(5, cl.getPRENOM());
				
				
				prepare.executeUpdate();
				cl = this.find(ID);	
				
			}
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    return cl;
	}
	
	
	
	public clients find(long id) {
		clients cl = new clients(id, 0, null, null, null);
		try {
            ResultSet result = this .connect
                                    .createStatement(
                                            	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                                ResultSet.CONCUR_UPDATABLE
                                             ).executeQuery(
                                                "SELECT * FROM clients WHERE ID = " + id
                                             );
            if(result.first())
            		cl = new clients(
                                        id, 
                                        result.getInt("VERSION"),
                                        result.getString("TITRE"),
                                        result.getString("NOM"),
                                        result.getString("PRENOM")
                                    );
            
		    } catch (SQLException e) {
		            e.printStackTrace();
		    }
		   return cl;

	}
	
	
	public clients update(clients cl) {
		try {
			
                this .connect	
                     .createStatement(
                    	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_UPDATABLE
                     ).executeUpdate(
                    	"UPDATE clients SET NOM = '" + cl.getNOM() + "'"+
                    	" WHERE id = " + cl.getID()
                     );
			
			cl = this.find(cl.getID());
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    
	    return cl;
	}


	public void delete(clients cl) {
		try {
			
                this    .connect
                    	.createStatement(
                             ResultSet.TYPE_SCROLL_INSENSITIVE, 
                             ResultSet.CONCUR_UPDATABLE
                        ).executeUpdate(
                             "DELETE FROM clients WHERE id = " + cl.getID()
                        );
			
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	}



	
}