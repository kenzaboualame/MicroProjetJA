package models.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DAO;
import models.creneaux;

public class creneauxDAO extends DAO<creneaux> {

	public creneaux create(creneaux cl) {
		try {
			 
		
			ResultSet result = this	.connect
                                    .createStatement(
                                    		ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                    		ResultSet.CONCUR_UPDATABLE
                                    ).executeQuery(
                                    		"SELECT NEXTVAL('creneaux_id_seq') as ID"
                                    );
			if(result.first()){
				int ID = result.getInt("ID");
    			PreparedStatement prepare = this	.connect
                                                    .prepareStatement(
                                                    	"INSERT INTO creneaux (ID, VERSION,HDEBUT,MDEBUT,HFIN,MFIN,ID_MEDECIN) VALUES(?,?,?,?,?,?,?)"
                                                    );
				prepare.setInt(1, ID);
				prepare.setInt(2, cl.getVERSION());
				prepare.setDouble(3, cl.getHDEBUT());
				prepare.setDouble(4, cl.getMDEBUT());
				prepare.setDouble(5, cl.getHFIN());
				prepare.setDouble(5, cl.getMFIN());
				prepare.setInt(5, cl.getID_MEDECIN());
				
				prepare.executeUpdate();
				cl = this.find(ID);	
				
			}
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    return cl;
	}
	
	
	
	public creneaux find(long id) {
		creneaux cl = new creneaux(0, 0, 0, 0, 0, 0, 0);
		try {
            ResultSet result = this .connect
                                    .createStatement(
                                            	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                                ResultSet.CONCUR_UPDATABLE
                                             ).executeQuery(
                                                "SELECT * FROM creneaux WHERE ID = " + id
                                             );
            if(result.first())
            		cl = new creneaux(
                                        id, 
                                        result.getInt("VERSION"),
                                        result.getString("HDEBUT"),
                                        result.getString("MDEBUT"),
                                        result.getString("HFIN"),
                                        result.getString("MFIN"),
                                        result.getString("ID_MEDECIN")
                                    );
            
		    } catch (SQLException e) {
		            e.printStackTrace();
		    }
		   return cl;

	}
	
	
	public creneaux update(creneaux cl) {
		try {
			
                this .connect	
                     .createStatement(
                    	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_UPDATABLE
                     ).executeUpdate(
                    	"UPDATE creneaux SET VERSION = '" + cl.getVERSION() + "'"+
                    	" WHERE id = " + cl.getID()
                     );
			
			cl = this.find(cl.getID());
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    
	    return cl;
	}


	public void delete(creneaux cl) {
		try {
			
                this    .connect
                    	.createStatement(
                             ResultSet.TYPE_SCROLL_INSENSITIVE, 
                             ResultSet.CONCUR_UPDATABLE
                        ).executeUpdate(
                             "DELETE FROM creneaux WHERE id = " + cl.getID()
                        );
			
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	}
}
