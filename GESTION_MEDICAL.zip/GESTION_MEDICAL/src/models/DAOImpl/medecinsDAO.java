package models.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DAO;
import models.medecins;

public class medecinsDAO {
	public medecins create(medecins cl) {
		try {
			 
		
			ResultSet result = this	.connect
                                    .createStatement(
                                    		ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                    		ResultSet.CONCUR_UPDATABLE
                                    ).executeQuery(
                                    		"SELECT NEXTVAL('medecin_id_seq') as ID"
                                    );
			if(result.first()){
				int ID = result.getInt("ID");
    			PreparedStatement prepare = this	.connect
                                                    .prepareStatement(
                                                    	"INSERT INTO medecins (ID, VERSION,TITRE,NOM,PRENOM VALUES(?,?,?,?,?)"
                                                    );
				prepare.setInt(1, ID);
				prepare.setInt(2, cl.getVERSION());
				prepare.setString(3, cl.getTITRE());
				prepare.setString(4, cl.getNOM());
				prepare.setString(5, cl.getPRENOM());
				
				
				prepare.executeUpdate();
				cl = this.find(ID);	
				
			}
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    return cl;
	}
	
	
	
	public medecins find(long id) {
		medecins cl = new medecins();
		try {
            ResultSet result = this .connect
                                    .createStatement(
                                            	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                                ResultSet.CONCUR_UPDATABLE
                                             ).executeQuery(
                                                "SELECT * FROM medecins WHERE ID = " + id
                                             );
            if(result.first())
            		cl = new medecins(
                                        id, 
                                        result.getInt("VERSION"),
                                        result.getString("TITRE"),
                                        result.getString("NOM"),
                                        result.getString("PRENOM")
                                    );
            
		    } catch (SQLException e) {
		            e.printStackTrace();
		    }
		   return cl;

	}
	
	
	public medecins update(medecins cl) {
		try {
			
                this .connect	
                     .createStatement(
                    	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_UPDATABLE
                     ).executeUpdate(
                    	"UPDATE medecins SET NOM = '" + cl.getNOM() + "'"+
                    	" WHERE id = " + cl.getID()
                     );
			
			cl = this.find(cl.getID());
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    
	    return cl;
	}


	public void delete(medecins cl) {
		try {
			
                this    .connect
                    	.createStatement(
                             ResultSet.TYPE_SCROLL_INSENSITIVE, 
                             ResultSet.CONCUR_UPDATABLE
                        ).executeUpdate(
                             "DELETE FROM medecins WHERE id = " + cl.getID()
                        );
			
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	}

}
