package models.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.DAO;
import models.rv;

public class rvDAO {
	private Object connect;


	public rv create(rv cl) {
		try {
			 
		
			ResultSet result = this	.connect
                                    .createStatement(
                                    		ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                    		ResultSet.CONCUR_UPDATABLE
                                    ).executeQuery(
                                    		"SELECT NEXTVAL('rv_id_seq') as ID"
                                    );
			if(result.first()){
				int ID = result.getInt("ID");
    			PreparedStatement prepare = this	.connect
                                                    .prepareStatement(
                                                    	"INSERT INTO rv (ID, JOUR,CLIENT,CRENEAU VALUES(?,?,?,?)"
                                                    );
				prepare.setInt(1, ID);
				prepare.setDate(2, cl.getJOUR());
				prepare.setInt(3, cl.getID_CLIENT());
				prepare.setInt(4, cl.getID_CRENEAU());
				
				
				
				prepare.executeUpdate();
				cl = this.find(ID);	
				
			}
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    return cl;
	}
	
	
	
	public rv find(long id) {
		rv cl = new rv(id, null, 0, null);
		try {
            ResultSet result = ((Connection) this .connect)
                                    .createStatement(
                                            	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                                                ResultSet.CONCUR_UPDATABLE
                                             ).executeQuery(
                                                "SELECT * FROM clients WHERE ID = " + id
                                             );
            if(result.first())
            		cl = new rv(
                                        id, 
                                        result.getDate("JOUR"),
                                        result.getInt("ID_CLIENT"),
                                        result.getString("ID_CRENEAU")
                               
                                    );
            
		    } catch (SQLException e) {
		            e.printStackTrace();
		    }
		   return cl;

	}
	
	
	public rv update(rv cl) {
		try {
			
                this .connect	
                     .createStatement(
                    	ResultSet.TYPE_SCROLL_INSENSITIVE, 
                        ResultSet.CONCUR_UPDATABLE
                     ).executeUpdate(
                    	"UPDATE rv SET JOUR = '" + cl.getJOUR() + "'"+
                    	" WHERE id = " + cl.getID()
                     );
			
			cl = this.find(cl.getID());
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	    
	    return cl;
	}


	public void delete(rv cl) {
		try {
			
                this    .connect
                    	.createStatement(
                             ResultSet.TYPE_SCROLL_INSENSITIVE, 
                             ResultSet.CONCUR_UPDATABLE
                        ).executeUpdate(
                             "DELETE FROM rv WHERE id = " + cl.getID()
                        );
			
	    } catch (SQLException e) {
	            e.printStackTrace();
	    }
	}

}
