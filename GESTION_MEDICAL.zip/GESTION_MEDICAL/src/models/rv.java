package models;

import java.sql.Date;

public class rv {
	int ID;
	Date JOUR;
	int ID_CLIENT;
	int ID_CRENEAU;
	public rv(long id2, Date date, int int1, String string) {
		// TODO Auto-generated constructor stub
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public Date getJOUR() {
		return JOUR;
	}
	public void setJOUR(Date jOUR) {
		JOUR = jOUR;
	}
	public int getID_CLIENT() {
		return ID_CLIENT;
	}
	public void setID_CLIENT(int iD_CLIENT) {
		ID_CLIENT = iD_CLIENT;
	}
	public int getID_CRENEAU() {
		return ID_CRENEAU;
	}
	public void setID_CRENEAU(int iD_CRENEAU) {
		ID_CRENEAU = iD_CRENEAU;
	}
	@Override
	public String toString() {
		return "rv [ID=" + ID + ", JOUR=" + JOUR + ", ID_CLIENT=" + ID_CLIENT + ", ID_CRENEAU=" + ID_CRENEAU + "]";
	}
	
	
}
