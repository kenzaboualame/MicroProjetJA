package models;

public class creneaux {
	private int ID;
	private int VERSION;
	private int HDEBUT;
	private int MDEBUT;
	private int HFIN;
	private int MFIN;
	private int ID_MEDECIN;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getVERSION() {
		return VERSION;
	}
	public void setVERSION(int vERSION) {
		VERSION = vERSION;
	}
	public int getHDEBUT() {
		return HDEBUT;
	}
	public creneaux(long id2, int vERSION, int string, int string2, int string3, int string4, int string5) {
		super();
		ID = (int) id2;
		VERSION = vERSION;
		HDEBUT = string;
		MDEBUT = string2;
		HFIN = string3;
		MFIN = string4;
		ID_MEDECIN = string5;
	}
	public void setHDEBUT(int hDEBUT) {
		HDEBUT = hDEBUT;
	}
	public int getMDEBUT() {
		return MDEBUT;
	}
	public void setMDEBUT(int mDEBUT) {
		MDEBUT = mDEBUT;
	}
	public int getHFIN() {
		return HFIN;
	}
	public void setHFIN(int hFIN) {
		HFIN = hFIN;
	}
	public int getMFIN() {
		return MFIN;
	}
	public void setMFIN(int mFIN) {
		MFIN = mFIN;
	}
	public int getID_MEDECIN() {
		return ID_MEDECIN;
	}
	public void setID_MEDECIN(int iD_MEDECIN) {
		ID_MEDECIN = iD_MEDECIN;
	}
	@Override
	public String toString() {
		return "creneaux [ID=" + ID + ", VERSION=" + VERSION + ", HDEBUT=" + HDEBUT + ", MDEBUT=" + MDEBUT + ", HFIN="
				+ HFIN + ", MFIN=" + MFIN + ", ID_MEDECIN=" + ID_MEDECIN + "]";
	}
	
	
}
