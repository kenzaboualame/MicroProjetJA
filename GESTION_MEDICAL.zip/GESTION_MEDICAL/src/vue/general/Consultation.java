package vue.general;

import javax.swing.JPanel;

public class Consultation extends JPanel {

	/**
	 * Create the panel.
	 */
	public Consultation() {

	}

}
