package vue.general;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Acceuil extends JPanel {

	/**
	 * Create the panel.
	 */
	public Acceuil() {
		
		JButton btnNewButton_2 = new JButton("RDV");
		add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Consultation");
		add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Medecin");
		add(btnNewButton);
		
		JLabel lblBienvenue = new JLabel("Bienvenue");
		lblBienvenue.setFont(new Font("Tahoma", Font.PLAIN, 33));
		add(lblBienvenue);

	}

}
