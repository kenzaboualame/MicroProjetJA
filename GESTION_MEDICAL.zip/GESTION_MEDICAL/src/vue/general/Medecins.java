package vue.general;

import javax.swing.JPanel;

public class Medecins extends JPanel {

	/**
	 * Create the panel.
	 */
	public Medecins() {

	}

}
