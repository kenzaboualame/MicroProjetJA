package vue.general;

import javax.swing.JPanel;

public class Clients extends JPanel {

	/**
	 * Create the panel.
	 */
	public Clients() {

	}

}
